const express = require("express");
const cors = require("cors");

const app = express();

const allowedOrigin = "https://crissadithya26.github.io";

app.use(cors({
  origin: allowedOrigin,
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type"]
}));

app.use(express.json({ limit: "10mb" }));

app.get("/", (req, res) => {
  res.json({
    status: "online",
    service: "Agentic RAG AI Backend",
    message: "Backend is running."
  });
});

app.post("/api/ask", async (req, res) => {
  try {
    const { question, context, sources = [] } = req.body || {};

    if (!question || !context) {
      return res.status(400).json({
        error: "Question and document context are required."
      });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is not configured on the server."
      });
    }

    const prompt = `
You are the reasoning engine for an Agentic Retrieval-Augmented Generation (RAG) research system.

Answer the user's question using ONLY the retrieved document context below.

Rules:
- Do not invent information.
- Do not use outside knowledge.
- If the answer is not supported by the provided context, say:
  "The answer was not found in the provided document."
- Give a clear, natural and concise answer.
- Mention relevant page numbers when available.
- Do not claim that information exists in the document unless it is supported by the context.

USER QUESTION:
${question}

RETRIEVED DOCUMENT CONTEXT:
${context}

SOURCE INFORMATION:
${JSON.stringify(sources)}
`;

    const geminiResponse = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" +
        encodeURIComponent(process.env.GEMINI_API_KEY),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }]
        })
      }
    );

    const data = await geminiResponse.json();

    if (!geminiResponse.ok) {
      console.error("Gemini API error:", data);
      return res.status(geminiResponse.status).json({
        error: "Gemini API request failed."
      });
    }

    const answer =
      data?.candidates?.[0]?.content?.parts?.[0]?.text ||
      "No answer was generated.";

    return res.json({ answer, sources });
  } catch (error) {
    console.error("Backend error:", error);
    return res.status(500).json({
      error: "Something went wrong while processing the request."
    });
  }
});

module.exports = app;
