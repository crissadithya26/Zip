# Agentic RAG AI — Vercel Backend

Vercel-ready Express API for the Agentic RAG AI project.

## Endpoint
POST `/api/ask`

Body:
```json
{
  "question": "What is this document about?",
  "context": "retrieved document text",
  "sources": [{"page": 1}]
}
```

Set `GEMINI_API_KEY` as a Vercel Environment Variable. Never commit the key to GitHub.
